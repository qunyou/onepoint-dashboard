/**
 * Created by lijun on 2016/12/16.
 */
export default {
  originTable: 'sindu_origin_table',
  draggableTable: 'sindu_dragger',
  dragging: 'sindu_dragging',
  static: 'sindu_static',
  handle: 'sindu_handle',
};

